<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'testove' );

/** Имя пользователя MySQL */
define( 'DB_USER', 'root' );

/** Пароль к базе данных MySQL */
define( 'DB_PASSWORD', '' );

/** Имя сервера MySQL */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'i%KHY`[i8xy!)(-At}Ux`~Kt=bXOV&F=93FSJ_b/OAdJ2RTU,q5P_[JEs]P&Ki1I' );
define( 'SECURE_AUTH_KEY',  'bu8PKwp`GF_*G| QC.}D@05>Jo3Q;e>}0#hUD0hRPFnf%NJ-_IU)+?(WO=No$$HA' );
define( 'LOGGED_IN_KEY',    '8FQGQ|7Kjibb*lC&~@eWevL&le`i ,c:;rJ*HY*`Ybo>Y8]a|[K}yMdaKN^3vrGi' );
define( 'NONCE_KEY',        'YSZh{ek]Bby_Pm{riQ*Z`0vL-17c{dRWiy,[q=l|Z&`iVP(}-E(g<DUp3X&<F85L' );
define( 'AUTH_SALT',        'T!o)(9FN+I6$q1cmJ&rc0B?Cx)4!3Z=N 1&@4j!U mHCipx3r[-1uVkEm8`THUhT' );
define( 'SECURE_AUTH_SALT', 'k0F!{AhrTzF4l#2<TuuoP/d}t)j|salR@Xh)uUuDo635w!,FWK4POb%:;6Q?LAe]' );
define( 'LOGGED_IN_SALT',   'TdA;?RhzO>FFnHRQs=6*7H>KBjV6.(o,Pt4;^f*f[Z)(PEh3T}F+`O#u0`i&^,1m' );
define( 'NONCE_SALT',       '.#yEz4(>$l~mXY%@Ka0DfHu:dv:e3(z[_g-4)y{6klN,@i>F#rZi.B#V28lCo&E1' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once( ABSPATH . 'wp-settings.php' );
